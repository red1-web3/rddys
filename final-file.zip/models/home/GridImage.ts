import { ImageProps } from "next/image";

export interface GridImage {
  class: string;
  img: ImageProps;
}
