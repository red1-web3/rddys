import { ImageProps } from "next/image";

export interface Feed {
  image: ImageProps;
  _class: string;
}
