export { default } from "./GridImage";
export * from "./GridImage";
