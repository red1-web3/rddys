export { default } from "./Hero";
export * from "./Hero";
