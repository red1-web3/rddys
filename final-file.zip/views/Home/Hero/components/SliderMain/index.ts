export { default } from "./SliderMain";
export * from "./SliderMain";
