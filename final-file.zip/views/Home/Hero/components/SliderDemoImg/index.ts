export { default } from "./SliderDemoImg";
export * from "./SliderDemoImg";
