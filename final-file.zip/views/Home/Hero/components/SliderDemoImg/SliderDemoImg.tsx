import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Controller, EffectCube, EffectFade } from "swiper";
import "swiper/css";
import "swiper/css/effect-cube";
import { sliderImageAndText } from "constant/home/hero";
import Image from "next/image";

function SliderDemoImg({ setController }: { setController: any }) {
  return (
    <div className="absolute top-6 lg:top-1/2 left-1/2 -translate-x-1/2 lg:-translate-y-1/2 w-[80%] lg:w-[35%] h-[70%] lg:h-[75%]">
      <Swiper
        onSwiper={setController}
        direction={"horizontal"}
        className="mySwiper h-[70vh] lg:h-full !pointer-events-none"
        effect="cube"
        modules={[Controller, EffectCube]}
        cubeEffect={{
          shadow: false,
          slideShadows: false,
          shadowOffset: 20,
          shadowScale: 0.94,
        }}
      >
        {sliderImageAndText.map(({ image }, i) => (
          <SwiperSlide key={i}>
            <div className="h-full w-full">
              <Image {...image} className="object-cover rounded-xl" />
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

export default SliderDemoImg;
