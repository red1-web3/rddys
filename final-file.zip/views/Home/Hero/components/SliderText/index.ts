export { default } from "./SliderText";
export * from "./SliderText";
