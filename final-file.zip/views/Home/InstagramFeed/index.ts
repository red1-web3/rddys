export { default } from "./IntagramFeed";
export * from "./IntagramFeed";
