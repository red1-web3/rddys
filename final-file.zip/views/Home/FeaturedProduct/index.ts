export { default } from "./FeaturedProduct";
export * from "./FeaturedProduct";
